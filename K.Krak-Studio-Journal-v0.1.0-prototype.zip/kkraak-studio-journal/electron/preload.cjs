const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('journalDesktop',Object.freeze({get:key=>ipcRenderer.sendSync('journal:get',key),set:(key,value)=>ipcRenderer.sendSync('journal:set',key,value),getDataDirectory:()=>ipcRenderer.sendSync('journal:directory')}));
