const {app,BrowserWindow,ipcMain,shell}=require('electron');
const path=require('node:path'); const fs=require('node:fs');
const file=()=>path.join(app.getPath('userData'),'studio-journal-data.json'); let data={};
function load(){try{data=JSON.parse(fs.readFileSync(file(),'utf8'));}catch(e){if(e.code!=='ENOENT')console.error('Lecture des données du Journal:',e);data={};}}
function save(){const f=file();fs.mkdirSync(path.dirname(f),{recursive:true});const t=f+'.tmp';fs.writeFileSync(t,JSON.stringify(data,null,2),{encoding:'utf8',mode:0o600});fs.renameSync(t,f);}
ipcMain.on('journal:get',(e,k)=>{e.returnValue=Object.hasOwn(data,k)?data[k]:null;});
ipcMain.on('journal:set',(e,k,v)=>{try{data[k]=v;save();e.returnValue=true;}catch(err){console.error(err);e.returnValue=false;}});
ipcMain.on('journal:directory',e=>{e.returnValue=app.getPath('userData');});
function create(){const w=new BrowserWindow({width:1480,height:960,minWidth:980,minHeight:680,backgroundColor:'#0c0b09',autoHideMenuBar:true,title:'K.Krak Studio — Studio 02 : Journal',webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true}});if(app.isPackaged)w.loadFile(path.join(__dirname,'..','dist','index.html'));else w.loadURL('http://127.0.0.1:5173');w.webContents.setWindowOpenHandler(({url})=>{if(url.startsWith('https://'))shell.openExternal(url);return {action:'deny'};});}
app.whenReady().then(()=>{load();create();app.on('activate',()=>{if(!BrowserWindow.getAllWindows().length)create();});});app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});app.on('before-quit',()=>{try{save();}catch(e){console.error(e);}});
