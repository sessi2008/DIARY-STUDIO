# K.Krak Studio — Studio 02 : Journal

Prototype fonctionnel de studio de journal personnel pour Windows / Electron. L'expérience est centrée sur une bibliothèque de livres visuels, une ouverture en double-page, une animation de retournement 3D, l'écriture de pages, des modèles prédéfinis et la création de types personnalisés.

## Fonctionnalités de cette version

- Bibliothèque de livres à couvertures visuelles, avec recherche, favoris et vue des livres récents.
- Modèles : journal intime, quotidien, notes, journal de projet, carnet de voyage, recettes.
- Création de livres et de types personnalisés (couverture, papier, description, préférence de confidentialité).
- Lecteur en double-page, animation CSS de retournement, navigation entre pages.
- Création de nouvelles pages, horodatage, liste des pages, suppression avec confirmation.
- Export d'un livre en JSON et export de la bibliothèque.
- Mode Electron : persistance dans un fichier JSON du répertoire utilisateur de l'application, hors du stockage du navigateur. En mode navigateur de développement, repli sur localStorage.
- Interface sombre noir/or, mode Performance implicite via `prefers-reduced-motion`.

## Installation Windows

1. Installer Node.js LTS (et npm).
2. Extraire le ZIP dans un dossier accessible en écriture.
3. Double-cliquer sur `INSTALLER-ET-LANCER.bat` pour installer les dépendances et démarrer l'application en mode développement.
4. Pour créer un installateur Windows : exécuter `CONSTRUIRE-INSTALLATEUR-WINDOWS.bat`.

Commandes manuelles :

```bash
npm install
npm run dev:desktop
npm run typecheck
npm run dist:win
```

## Stockage

En mode bureau, le processus principal Electron écrit les données dans `studio-journal-data.json` sous le répertoire `app.getPath('userData')`. L'application effectue une écriture temporaire puis un renommage. Le bouton d'export permet de conserver une sauvegarde externe.

## Limites connues — à ne pas confondre avec des fonctions terminées

- L'animation est une première simulation 3D CSS du feuilletage. Elle ne reproduit pas encore une physique de papier complète ni le glisser-déposer du coin de page.
- Les pages sont des entrées textuelles. Un éditeur riche avec images, pièces jointes, blocs repositionnables et mise en page spécifique à chaque type reste à construire.
- Le verrouillage par livre est un verrouillage d'interface uniquement. Il n'y a pas encore de mot de passe, de chiffrement cryptographique ou de protection contre l'accès direct au fichier de données. Ne pas y stocker de secrets sensibles dans cette version.
- L'export de livre est JSON ; import/restauration guidée, corbeille et historique de versions restent à développer.
- Aucun service de synchronisation multi-appareils n'est implémenté.
- La compilation et la génération de l'installateur doivent être exécutées dans un environnement disposant des dépendances npm. Elles ne sont pas certifiées par le simple fait que l'archive a été créée.

## Structure

- `src/App.tsx` : bibliothèque, lecteur, modèles, pages et interactions.
- `src/styles.css` : identité visuelle, couvertures, animation de feuilletage et responsive.
- `electron/main.cjs` / `electron/preload.cjs` : fenêtre sécurisée et stockage local via IPC.
- `docs/CAHIER-DES-CHARGES.md` : exigences et étapes de développement.
