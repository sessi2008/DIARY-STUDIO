# Cahier des charges — Studio 02 : Journal

## Vision
Créer un espace d'écriture local qui traite les journaux comme de vrais livres numériques : couvertures, dos et tranche visuels, ouverture animée, double-page, retournement de page et retour ultérieur au même contenu.

## Exigences confirmées
- Le studio est le numéro 02 de K.Krak Studio.
- Les livres doivent ressembler à de vrais livres et s'ouvrir comme tels.
- Les pages doivent se tourner avec une animation qui évoque le papier réel.
- Plusieurs types de livres sont disponibles et l'utilisateur peut créer ses propres types.
- La confidentialité est prévue par livre.
- L'application de bureau privilégie le fonctionnement local/hors ligne.
- La suite utilise un univers noir profond, or chaud, turquoise et violet, avec animations réglables et réduction de mouvement.

## Types prévus dans le prototype
Journal intime, journal quotidien, carnet de notes, journal de projet, carnet de voyage, livre de recettes, types personnalisés.

## Modèle de données
- `BookType`: identifiant, nom, description, thème de couverture, style de page, préférence de confidentialité.
- `Book`: identifiant stable, titre, type, sous-titre, couverture, style de papier, dates de création/modification, pages, état de verrouillage d'interface, favori.
- `Entry`: identifiant stable, date, titre, corps textuel.

## Architecture actuelle
React + TypeScript + Vite dans le rendu. Electron avec `contextIsolation`, `nodeIntegration: false`, preload limité et IPC synchrone pour lire/écrire un fichier JSON dans le répertoire utilisateur. Un repli localStorage existe uniquement pour le mode navigateur.

## Prochaines étapes recommandées
1. Installer et compiler sur Windows, corriger les éventuels avertissements/erreurs de type.
2. Remplacer la simulation CSS par un moteur de feuilletage plus réaliste avec drag du coin, courbure et ombres contrôlées.
3. Ajouter un éditeur riche et des gabarits de pages configurables par type.
4. Mettre en place la confidentialité réelle : mot de passe, chiffrement au repos, gestion des clés et tests d'accès.
5. Ajouter sauvegardes versionnées, restauration/import avec validation, corbeille et historique.
6. Prévoir des tests de non-régression, d'accessibilité clavier, de performances et de récupération après fermeture brutale.
7. Définir une migration versionnée avant tout changement de format de données.

## Limites importantes
Le prototype n'est pas encore un système de coffre-fort chiffré. Le verrouillage masque l'ouverture dans l'interface seulement. L'animation est une première version visuelle et ne simule pas encore toutes les propriétés physiques du papier. La synchronisation multi-appareils n'est pas implémentée.
