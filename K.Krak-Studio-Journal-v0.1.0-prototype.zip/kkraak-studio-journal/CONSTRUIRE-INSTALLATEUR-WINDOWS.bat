@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js est requis.& pause & exit /b 1)
if not exist node_modules (echo Installation des dependances...& npm install || (echo Echec npm install.& pause & exit /b 1))
echo Verification TypeScript...
npm run typecheck || (echo La verification TypeScript a echoue. Corrigez les erreurs avant de continuer.& pause & exit /b 1)
echo Construction de l'installateur Windows...
npm run dist:win
if errorlevel 1 (echo La construction a echoue.& pause & exit /b 1)
echo Terminé. Regardez le dossier release.
pause
