# Checklist de vérification manuelle

- [ ] L'application démarre sans écran vide.
- [ ] La bibliothèque montre les livres exemples.
- [ ] La recherche filtre les livres.
- [ ] Le filtre Favoris fonctionne.
- [ ] Un livre s'ouvre en double-page.
- [ ] Page suivante/précédente déclenche une animation.
- [ ] Une nouvelle page peut être écrite puis rouverte.
- [ ] Le contenu survit à la fermeture puis au redémarrage d'Electron.
- [ ] Un livre peut être créé à partir d'un modèle.
- [ ] Un type personnalisé peut être créé et réutilisé.
- [ ] Export d'un livre JSON fonctionne.
- [ ] Export de la bibliothèque fonctionne.
- [ ] Le verrouillage affiche son avertissement explicite.
- [ ] `npm run typecheck` passe.
- [ ] `npm run dist:win` produit l'installateur.
