@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ================================================
echo   K.Krak Studio — Studio 02 : Journal
echo ================================================
where node >nul 2>nul || (echo Node.js est requis. Installez Node.js LTS puis relancez ce fichier.& pause & exit /b 1)
if not exist node_modules (echo Installation des dependances...& npm install || (echo Echec npm install.& pause & exit /b 1))
echo Lancement du Studio Journal...
npm run dev:desktop
pause
